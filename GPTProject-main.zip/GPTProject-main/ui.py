#need to run in command line: python3 -m pip install --upgrade tk     
#seems to only work with python 3 for me
#from cohere import Client
import tkinter as tk
import webbrowser
from tkinter import PhotoImage
from cohere import Client
import os
from dotenv import load_dotenv
from response_generator import get_response, START_MESSAGE, START_QUESTIONS

#formats some font size and type stuff
FONT = ("Courier", 12)
FONT_BOLD = ("Courier", 16, "bold")


#stores all of the gui stuff in this class
class GUI_APP:
    def __init__(self):
        load_dotenv()
        self.window = tk.Tk()
        self.setup_main_window()
        #personal info to fill out
        self.personal_info_statement = None
        self.max_tokens = 100000
        cohere_key = os.getenv("COHERE_KEY")
        self.co = Client(cohere_key)
        self.chat_history = [{"user_name": "User", "text": "You should make html code for a website about me and my professinal expiernce. Use relevant images from the internet. Also include inline css for styling."},
                             {"user_name": "Chatbot", "text": "Awesome tell me about yourself so I can provide html for a portfolio website"},]

    #basically starts everything to run together
    def run(self):
        #called after setup is called and prints the instructions 
        self.text_widget.configure(state=tk.NORMAL)
        self.text_widget.insert(tk.END, START_MESSAGE)
        self.text_widget.insert(tk.END, START_QUESTIONS)
        self.text_widget.configure(state=tk.DISABLED)
        self.window.mainloop()

        #connect to api
        ## LOAD FROM .env FILE SO WE DO NOT COMMIT THE KEY


        

    def setup_main_window(self):
        self.window.title("Portfolio GPT")
        self.window.resizable(width=True, height=True)
        self.window.configure(width=1200, height=700, bg="white")
        self.send_img = PhotoImage(file="send_img.png")
        
        # head label
        head_label = tk.Label(self.window, bg="black", fg="white",
                           text="Portfolio GPT --- A Project by The ML Breakfast Club", font=FONT_BOLD, pady=10)
        head_label.place(relwidth=1)
        
        # tiny divider
        line = tk.Label(self.window, width=450, bg="grey")
        line.place(relwidth=1, rely=0.07, relheight=0.012)
        
        # text widget
        self.text_widget = tk.Text(self.window, width=20, height=2, bg="white", fg="black",
                                font=FONT, padx=5, pady=5)
        self.text_widget.place(relheight=0.845, relwidth=1, rely=0.08)
        self.text_widget.configure(cursor="arrow")
        
        # scroll bar
        scrollbar = tk.Scrollbar(self.text_widget)
        scrollbar.place(relheight=1, relx=0.974)
        scrollbar.configure(command=self.text_widget.yview)
        
        # bottom label
        bottom_label = tk.Label(self.window, bg="grey", height=80)
        bottom_label.place(relwidth=1, rely=0.9)
        
        # message entry box
        self.msg_entry = tk.Entry(bottom_label, bg="white", fg="black", font=FONT)
        self.msg_entry.place(relwidth=0.74, relheight=0.02, rely=0.008, relx=0.011)
        self.msg_entry.focus()
        self.msg_entry.bind("<Return>", self.send_msg)
        
        # send button
        send_button = tk.Button(bottom_label, image=self.send_img,text="Send", font=FONT_BOLD, width=20, bg="white", command=lambda: self.send_msg(None))
        send_button.place(relx=0.76, rely=0.008, relheight=0.02, relwidth=0.11)

        view_button = tk.Button(bottom_label, text="Preview", font=FONT_BOLD, width=20, bg="white", command=lambda: self.view_site(None))
        view_button.place(relx=0.88, rely=0.008, relheight=0.02, relwidth=0.11)
     
    #gets called when the send button is pressed or when enter/return is pressed on keyboard
    def send_msg(self, event):
        msg = self.msg_entry.get()
        self.insert_text(msg, "You", True) #inserts your text calling insert_text() method
    
    def view_site(self, event):
        # allows user to view webpage in browser
        webbrowser.open('webpage.html')

    def make_html(self,text):
        file_name = "webpage.html"
        with open(file_name, "w") as file:
            file.write(text)

        file.close()

    def strip_output_text(self):
        with open("webpage.html", 'r') as file:
            file_content = file.read()

            # Find the indices of <!DOCTYPE html> and </html>
            start_index = file_content.find('<!DOCTYPE html>')
            end_index = file_content.find('</html>', start_index)

            # Extract the content between the two indices
            html_content = file_content[start_index:end_index + len('</html>')]

            print(html_content)
        # Write the extracted content to a new file
        with open("webpage.html", 'w') as output_file:
            output_file.write(html_content)
        file.close()
    def insert_text(self, msg, sender, first_chat):
        if not msg: #prevents nothing from being entered if button hit accidentally
            return

        if (msg.upper() in ["Q", "QUIT"]):
            self.window.destroy()
            return

        #main chatbot and printing logic
        self.msg_entry.delete(0, tk.END)
        msg_user = f"USER: {msg}\n"
        self.text_widget.configure(state=tk.NORMAL)
        self.text_widget.insert(tk.END, msg_user)
        self.text_widget.configure(state=tk.DISABLED)
        
        msg_bot = f"Portfolio GPT: {get_response(msg, self.chat_history, self.co, first_chat)}\n\n"
        #strip html
        self.make_html(msg_bot)  # calls the html maker based on answer with non html stripped out
        self.strip_output_text()
        self.text_widget.configure(state=tk.NORMAL)
        self.text_widget.insert(tk.END, msg_bot)
        self.text_widget.configure(state=tk.DISABLED)
        self.text_widget.see(tk.END)
        

             
        
if __name__ == "__main__":
    app = GUI_APP()
    app.run()