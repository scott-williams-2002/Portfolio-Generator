from dotenv import load_dotenv
from cohere import Client
import webbrowser
import re
import os
import pinecone
import numpy as np

## LOAD FROM .env FILE SO WE DO NOT COMMIT THE KEY
load_dotenv()

cohere_key = os.getenv("COHERE_KEY")
pinecone_key = os.getenv("PINECONE_KEY")
max_tokens = 100000
co = Client(cohere_key)
pinecone.init(api_key=pinecone_key, environment="gcp-starter")
index_name = 'cohere-pinecone-trec'
index_count = 0


# change this to prompt engineer
chat_history = [
	{"user_name": "User", "text": "You should make html code for a website about me and my professinal expiernce. Use relevant images from the internet. Also include inline css for styling."},
	{"user_name": "Chatbot", "text": "Awesome tell me about yourself so I can provide html for a portfolio website"},
]

name = input("What is your full name?> ")
likes = input("Please list some of your likes, delimited by commas?> ")
dislikes = input("Please list some of your dislikes, delimited by commas?> ")
experience = input("Please tell me about your general expierence and/or soft skills?> ")
projects = input("What cool projects have  you've worked on?> ")
links = input("Do you have any links you want be to append?> ")
style = input("What type of style are you looking for, for this portfolio?> ")
college = input("Where did you graduate?> ")
grad = input("When did you graduate (month and year)?> ")
all_embeddings = []
tokens = []
for _ in range(10):

	if(_ == 0):
		message = f"""
		Here's some info about myself:
		My name is {name}, I like {likes}, I dislike {dislikes}. I graduate from {college} in {grad}.
		Here's some relevant experience that I would like you to put on my website: {experience}, with a section dedicated to these projects: {projects}.

		If the following includes a link, then please put it as an external link: {links}. 
		Can you please generate a website in a {style} style with all of this information and relevant images from the internet?
		"""
	else:
		message = input("Enter response for bot, or enter Q/QUIT to quit> ")

	if(message.upper() in ["Q", "QUIT"]):
		break

	xq = co.embed(
    texts=["Return All Results Placeholder"],
    model='small',
    truncate='LEFT'
	).embeddings

	if _!= 0:
		query_params = {
			'top_k': index_count  # Adjust this number according to your expected number of vectors
		}
		query_results = index.query(xq, **query_params, include_metadata=True, include_values=True)
		
	

    # can change temperature as needed
    # this generates response
	response = co.chat(
		message=message,
		chat_history=all_embeddings,
		temperature=0.8
	)
	# Embed the response
	embeds = co.embed(
    texts=[response.text],
    model='small',
    truncate='LEFT'
	).embeddings

	message_embed = co.embed(
	texts=[message],
	model='small',
	truncate='LEFT'
	).embeddings

	answer = response.text

	response_shape = np.array(embeds).shape
	message_shape = np.array(message_embed).shape


	# if the index does not exist, we create it
	if index_name not in pinecone.list_indexes():
		pinecone.create_index(
			index_name,
			dimension=response_shape[1],
			metric='cosine'
		)

	print(answer)

	index = pinecone.Index(index_name)

	batch_size = 128

	ids = [str(i) for i in range(response_shape[0])]
	# create list of metadata dictionaries
	meta = [{'text': text,'user_name': 'Chatbot'} for text in [response.text]]

	to_upsert = list(zip(ids, embeds, meta))
	# upsert/push all the embeddings
	for i in range(0, response_shape[0], batch_size):
		i_end = min(i+batch_size, response_shape[0])
		index.upsert(vectors=to_upsert[i:i_end])
		index_count += 1
	# Upsert the Message as well
	ids = [str(i) for i in range(message_shape[0])]
	# create list of metadata dictionaries
	meta = [{'text': text, 'user_name': 'User'} for text in [message]]

	to_upsert = list(zip(ids, embeds, meta))
	# upsert/push all the embeddings
	for i in range(0, message_shape[0], batch_size):
		i_end = min(i+batch_size, message_shape[0])
		index.upsert(vectors=to_upsert[i:i_end])
		index_count += 1
	if _ != 0:
		for match in query_results['matches']:
			all_embeddings.append(match['metadata'])
			tokens.append(match['metadata']['text'])

    # probably need to delete old chats at some point to not exceed token limit

	#I gotchu fam.
	tokens_used = sum(len(text.split()) for text in tokens)
	while(tokens_used > max_tokens):
		# query all embeddings, find the average. Find the closest message and closest answer and remove
		average_vector = np.mean(query_results['matches']['values'], axis=0)

		closest_message_embeddings = []
		closest_response_embeddings = []
		for embedding in all_embeddings:
			distance = np.linalg.norm (embedding, average_vector)
			if embedding['user_name'] == 'User':
				closest_message_embeddings.append((embedding, distance))
			if embedding['user_name'] == 'User':
				closest_response_embeddings.append((embedding, distance))
		closest_message_embeddings.sort(key=lambda x: x[1])
		closest_response_embeddings.sort(key=lambda x: x[1])
		index.delete(
			filter={
				"text": {"$eq": closest_message_embeddings[0]['text']},
				"text": {"$eq": closest_response_embeddings[0]['text']},
			}
		)

		query_results = index.query(xq, **query_params, include_metadata=True, include_values=True)
		all_embeddings = []
		tokens = []
		for match in query_results['matches']:
			all_embeddings.append(match['metadata'])
			tokens.append(match['metadata']['text'])

		# chat_history = chat_history[2:] #Since it includes both message and answer, we cut out first two responses.
		# tokens_used = sum([len(i["text"].split(" ")) for i in chat_history])
