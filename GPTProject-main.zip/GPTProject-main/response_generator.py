from cohere import Client

#this method takes the client object and chat info to get an output
def get_response(string_input, chat_history, cohere_client, first_question):
    response = cohere_client.chat(
        message=string_input,
        chat_history=chat_history,
        temperature=0.8
    )

    answer = response.text

    chat_history.append({"user_name": "User", "text": string_input})
    chat_history.append({"user_name": "Chatbot", "text": answer})

    # probably need to delete old chats at some point to not exceed token limit

    # I gotchu fam.
    tokens_used = sum([len(i["text"].split(" ")) for i in chat_history])
    while (tokens_used > 100000):
        chat_history = chat_history[2:]  # Since it includes both message and answer, we cut out first two responses.
        tokens_used = sum([len(i["text"].split(" ")) for i in chat_history])
    return answer


#this is the message that is displayed first when starting the program
START_MESSAGE = """
Hello Welcome Porfolio GPT!
This project is mean to help you automate the process of making a portfolio website.
Use the button with the send icon to send message and recieve a response. 
The Preview button allows the HTML code to be run on your browser.
Lets start by getting some information to use to build your website. 

"""


START_QUESTIONS = """
What is your full name?
Please list some of your likes, delimited by commas. 
Please list some of your dislikes, delimited by commas.
Please tell me about your general expierence and/or soft skills.
What cool projects have  you've worked on.
Do you have any links you want be to append.
What type of style are you looking for, for this portfolio?
Where did you graduate?
When did you graduate (month and year)?
What is your email address?
What is your phone number?

Try to answer in a format like this:
'''
My name is John, I like golf, football, and coding, I dislike pizza. 
I graduate from The Colorado School of Mines in May 2020. 
Here's some relevant experience that I have had: I am great in a team setting. 
I worked on these projects: GPT Project and KNN Project. 
Here is a link to my Github: 
I would like to make my website by styled in a professional and fun way. 
Also I want to have relevant images from the internet on my webpage. 
Add in my phone number, which is 111 111 1111 and email: example@mines.edu on the page. 
'''
"""
                   
                   



