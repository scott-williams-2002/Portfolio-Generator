from GUI import gui
import tkinter as tk
#root = tk.Tk()
#chatbot_gui = gui.ChatbotGUI(root)
#chatbot_gui.set_bot_msg("hello")
#root.mainloop()
    